function humidInit = DryCoolGasFlowRate()
clear all;
humidInit = 20;
end